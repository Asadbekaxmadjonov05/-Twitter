import React from 'react'
import Navbar from '../../components/Navbar'

function Home() {
  return (
    <div className='container mx-auto px-5'>
      <Navbar/>
      <div className='w-[50%]'></div>
      <div className='w-[25%]'></div>
    </div>
  )
}

export default Home
