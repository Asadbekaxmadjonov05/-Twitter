import Home from "./Home"
import Profile from "./Profile"
export {Home, Profile}