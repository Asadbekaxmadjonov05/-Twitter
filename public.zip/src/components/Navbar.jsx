import React from 'react';
import { Link,} from 'react-router-dom';
import { TwitterIcon, HomeIcon, ExploreIcon, NotificationIcon, MassagesIcon , BookmarksIcon, ListsIcon, ProfileFillIcon, MoreICon} from "../components/Icons";
import NavbarItem from './NavbarItem';

function Navbar() {
    const navbarList = [
        {
            id:1,
            titel:"Home",
            path:"/",
            icon:<HomeIcon/>,
        },
        {
            id:2,
            titel:"Explore",
            path:"/explore",
            icon:<ExploreIcon/>,
        },
        {
            id:3,
            titel:"Notification",
            path:"/notification",
            icon:<NotificationIcon/>,
        },
        {
            id:4,
            titel:"Massages",
            path:"/massages",
            icon:<MassagesIcon/>,
        },
        {
            id:5,
            titel:"Bookmarks",
            path:"/bookmarks",
            icon:<BookmarksIcon/>,
        },
        {
            id:6,
            titel:"Lists",
            path:"/lists",
            icon:<ListsIcon/>,
        },
        {
            id:7,
            titel:"ProfileFill",
            path:"/profileFill",
            icon:<ProfileFillIcon/>,
        },
        {
            id:8,
            titel:"More",
            path:"/more",
            icon:<MoreICon/>,
        },
    ]
  return (
    <div className="w-[25%] pt-[31px] pr-[53px]">
      <Link to={'/'}>
        <TwitterIcon />
      </Link>
      <ul className='mt-[49px] space-y-[30px]'>
        {navbarList.map(item =><NavbarItem key={item.id} item={item}/>)}
        
      </ul>
    </div>
  );
}

export default Navbar;
